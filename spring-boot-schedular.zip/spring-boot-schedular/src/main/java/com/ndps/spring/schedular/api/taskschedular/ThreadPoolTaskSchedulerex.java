package com.ndps.spring.schedular.api.taskschedular;

import java.util.Date;
import java.util.concurrent.ScheduledFuture;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.scheduling.support.PeriodicTrigger;
import org.springframework.stereotype.Component;

import lombok.extern.java.Log;

@Log
@Component
public class ThreadPoolTaskSchedulerex {

	@Autowired
	private ThreadPoolTaskScheduler taskScheduler;
	@Autowired
	private CronTrigger cronTrigger;
	@Autowired
	private PeriodicTrigger periodicTrigger;

	@PostConstruct
	public void scheduleRunnableWithCronTrigger() {
		taskScheduler.schedule(new RunnableTask("Current Date"), new Date());
		// The RunnableTask will always run 1000 milliseconds later between the
		// completion of one execution and the start of the next.
		taskScheduler.scheduleWithFixedDelay(new RunnableTask("Fixed 1 second Delay"), 1000);

		taskScheduler.scheduleWithFixedDelay(new RunnableTask("Current Date Fixed 1 second Delay"), new Date(), 1000);

		// The RunnableTask will run 2000 milliseconds after the current time.
		taskScheduler.scheduleAtFixedRate(new RunnableTask("Fixed Rate of 3 seconds"), new Date(), 3000);

		// The next RunnableTask will always run after 2000 milliseconds, regardless of
		// the status of the last execution, which may still be running.
		taskScheduler.scheduleAtFixedRate(new RunnableTask("Fixed Rate of 2 seconds"), 2000);

		// In this case, the RunnableTask will be executed at the 10th second of every minute.
		taskScheduler.schedule(new RunnableTask("Cron Trigger"), cronTrigger);

		taskScheduler.schedule(new RunnableTask("Periodic Trigger"), periodicTrigger);
	}

	class RunnableTask implements Runnable {

		private String message;

		public RunnableTask(String message) {
			this.message = message;
		}

		@Override
		public void run() {
			//log.info(String.format("Runnable with message: %s ,on thread %s date: %s", message,
				//	Thread.currentThread().getName(), new Date()));
		}
	}
}
